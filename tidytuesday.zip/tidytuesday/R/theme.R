# One consistent look across every weekly chart.
library(ggplot2)

theme_tt <- function(base_size = 12) {
  theme_minimal(base_size = base_size) +
    theme(
      plot.title.position   = "plot",
      plot.title            = element_text(face = "bold", size = rel(1.3)),
      plot.subtitle         = element_text(colour = "grey35", margin = margin(b = 10)),
      plot.caption          = element_text(colour = "grey50", hjust = 0, size = rel(0.8)),
      panel.grid.minor      = element_blank(),
      panel.grid.major.y    = element_line(colour = "grey90"),
      panel.grid.major.x    = element_blank(),
      legend.position       = "top",
      legend.title          = element_blank(),
      plot.margin           = margin(15, 15, 10, 15)
    )
}

# Consistent caption: source and tool
tt_caption <- function(source = "TidyTuesday") {
  paste0("Source: ", source, "  |  Made with R and ggplot2")
}
