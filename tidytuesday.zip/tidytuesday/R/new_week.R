# Start a new TidyTuesday week.
#
# Usage (from the project root):
#   source("R/new_week.R")
#   new_week()                      # most recent Tuesday
#   new_week("2026-09-15")          # a specific week
#
# Creates  <year>/<date>/analysis.qmd  from templates/analysis_template.qmd

new_week <- function(date = tidytuesdayR::last_tuesday()) {
  date   <- as.Date(date)
  year   <- format(date, "%Y")
  folder <- file.path(year, as.character(date))
  dir.create(folder, recursive = TRUE, showWarnings = FALSE)

  target <- file.path(folder, "analysis.qmd")
  if (file.exists(target)) {
    message("Already exists: ", target)
    return(invisible(target))
  }

  template <- readLines("templates/analysis_template.qmd")
  template <- gsub("{{DATE}}", as.character(date), template, fixed = TRUE)
  writeLines(template, target)

  message("Created ", target)
  message("Next: open it, read the data dictionary, and pick ONE question.")
  invisible(target)
}
