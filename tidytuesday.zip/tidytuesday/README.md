# TidyTuesday

My weekly submissions to [#TidyTuesday](https://github.com/rfordatascience/tidytuesday), a community project that shares a new dataset every week for practicing data wrangling and visualization in R.

**Goal:** one clear question, one clean chart, one short takeaway each week, built quickly and honestly.

**Tools:** R, tidyverse, ggplot2, Quarto, `tidytuesdayR`

## Gallery

| Week | Topic | Chart | Code |
|---|---|---|---|
| *(date)* | *(dataset name)* | *(![](2026/DATE/plot.png))* | *(link to analysis.qmd)* |

## How I run each week

1. `source("R/new_week.R"); new_week()` creates a folder with the analysis template
2. Read the data dictionary and write **one** question before plotting
3. Wrangle, plot, and render the Quarto file (time box: about 90 minutes)
4. Save `plot.png`, add a row to the gallery above, commit

## Checklist for every submission

- [ ] One question stated up front
- [ ] Title states the finding, not just the topic
- [ ] Axes and legend are labeled and readable
- [ ] Source caption included
- [ ] Code runs top to bottom in a fresh R session
- [ ] One new thing tried this week

## Skills practiced

Tracking what I learn each week (update as you go):

| Week | New skill or function |
|---|---|
| | |

## Reproduce

```r
install.packages(c("tidyverse", "tidytuesdayR", "janitor", "quarto"))
source("R/new_week.R")
new_week("YYYY-MM-DD")
```

## Structure

```
R/theme.R                        shared ggplot theme and caption helper
R/new_week.R                     creates a new week from the template
templates/analysis_template.qmd  weekly analysis template
2026/<date>/analysis.qmd         each week's analysis and plot
```
